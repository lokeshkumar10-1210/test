package com.test.java.thread;

public class Testing {

	public static void main(String[] args) {
		int[] arr ={1 , 2 , 3 , 1 , 8 };
		int k= 10;
		m1(arr, k);
	}
	public static void m1(int[] arr, int k) {
		for (int i=0; i<arr.length;i++) {
		 for(int j=i+1; j<arr.length;j++){
			if (arr[i] + arr[j]==k) {
			System.out.println("index of 1st element = " + arr[i]  + "   index of 2st element = " + arr[j]); 
		break;
			}
		}
		}

		}

}
