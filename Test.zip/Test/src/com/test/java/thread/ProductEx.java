package com.test.java.thread;

import java.util.stream.Collectors;

public class ProductEx {

	public static void main(String[] args) {
		
		Map<String, Long> order = list.stream().collect(Collectors.groupingBy())

	}
	
	
	 
	

}

class Order { 
	
	
	List<Product> product}
}
class Product {
	private String product;
	Product(String product){
		this.product = product;
	}
	}
