package com.test.java.thread;

class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread is running");
    }
}

public class RunnableEx {
    public static void main(String[] args) {
        Thread t1 = new Thread(new MyRunnable()); // Create a Thread with MyRunnable
        t1.start(); // Start the thread
        MyRunnable t2= new MyRunnable();
        t2.run(); // directly will execute the task in the current thread, not a new one
    }
}