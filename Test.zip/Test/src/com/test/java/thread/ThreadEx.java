package com.test.java.thread;

class MyThread extends Thread {
	public void run() {
		System.out.println("Thread is running");
	}
}

public class ThreadEx {
	public static void main(String[] args) {
		MyThread t1 = new MyThread(); // Create an instance of MyThread
		t1.start(); // Start the thread
	}
}