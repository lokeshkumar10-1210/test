package com.test.java.thread;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestEx {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("Alok", "Amit", "CHandan", "Ram", "Suresh");

		Map<String, Integer> output = list.stream().collect(Collectors.toMap(item -> item, // key
				String::length, // value
				(a, b) -> a, // merge function (not used here)
				LinkedHashMap::new // map supplier

		));
		
		output.entrySet().forEach(System.out::println);
		

		HashMap<String, Integer> hs = new HashMap<>();
		hs.put("A", 1);
		hs.put("B", 2);
		hs.put("A", 3);
		System.out.println("HashMap =  " + hs.get("A") + " ss= " + hs);
		
		String s1= "Hello";
		String s2 = "Hello";
		String s3 = new String("Hello");
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s1.equals(s3));
	}

}
