package com.test.java8;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateTimeEx {
	public static void main(String[] args) {
		// Get the current date
		LocalDate today = LocalDate.now();
		System.out.println("Today's Date: " + today); // e.g., 2026-03-06

		// Get the current date and time with a specific time zone
		ZonedDateTime zonedNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
		System.out.println("Current Time in Kolkata: " + zonedNow); // e.g., 2026-03-06T17:18:00+05:30[Asia/Kolkata]

		// Add days to a date
		LocalDate tomorrow = today.plusDays(1);
		System.out.println("Tomorrow's Date: " + tomorrow); // e.g., 2026-03-07
	}
}