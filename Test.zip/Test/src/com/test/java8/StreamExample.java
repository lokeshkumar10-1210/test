package com.test.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamExample {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

		List<Integer> results = numbers.stream().filter(n -> n % 2 == 0).map(n -> n * 2).collect(Collectors.toList());
		System.out.println(results);

		List<String> names = Arrays.asList("John", "Alice", "Bob", "Anna");
		List<String> filteredNames = names.stream().filter(name -> name.startsWith("A")).collect(Collectors.toList());

		System.out.println(filteredNames);

		List<String> upperCaseNames = names.stream().map(String::toUpperCase) // Using method reference
				.collect(Collectors.toList());

		System.out.println(upperCaseNames);

		List<String> sortedNames = names.stream().sorted().collect(Collectors.toList());
		System.out.println(sortedNames);

		int sum = numbers.stream().reduce(0, (a, b) -> a + b);
		System.out.println(sum);

		List<String> distinct = names.stream().distinct().collect(Collectors.toList());
		System.out.println(distinct);

		List<List<Integer>> nestedList = Arrays.asList(Arrays.asList(1, 2), Arrays.asList(3, 4), Arrays.asList(5, 6));

		List<Integer> flattenedList = nestedList.stream().flatMap(List::stream).collect(Collectors.toList());
		System.out.println(flattenedList);
		List<String> myList = Arrays.asList("apple", "banana", "orange", "graps", "kiwi");

		Map<Integer, List<String>> groupedByLength = myList.stream().collect(Collectors.groupingBy(String::length));

		System.out.println(groupedByLength);
		Map<Boolean, List<String>> partitioned = myList.stream()
				.collect(Collectors.partitioningBy(s -> s.length() > 4));
		System.out.println(partitioned);
		
		List<String> result = myList.stream()
                .peek(System.out::println)
                .collect(Collectors.toList());

	}

}
