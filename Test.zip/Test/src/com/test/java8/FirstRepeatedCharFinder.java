package com.test.java8;

import java.util.HashSet;
import java.util.OptionalInt;
import java.util.Set;

public class FirstRepeatedCharFinder {

	public static Character findFirstRepeatedChar(String str) {
		// A Set does not allow duplicate elements
		Set<Character> seenCharacters = new HashSet<>();

		for (char c : str.toCharArray()) {
			// Try to add the character to the set
			if (!seenCharacters.add(c)) {
				// If add returns false, the character is already present, so it's the first
				// repeated one
				return c;
			}
		}

		// If the loop finishes without returning, there are no repeated characters
		return null;
	}

	public static void main(String[] args) {
		String input1 = "abccba";
		String input2 = "hello world";
		String input3 = "abcde";

		System.out.println("Input: \"" + input1 + "\", First repeated char: " + findFirstRepeatedChar(input1));
		//System.out.println("Input: \"" + input2 + "\", First repeated char: " + findFirstRepeatedChar(input2));
		//System.out.println("Input: \"" + input3 + "\", First repeated char: " + findFirstRepeatedChar(input3));

		String input = "abccba";
		Set<Integer> seen = new HashSet<>();

		// Use a stream of characters (IntStream) to filter for the first repeated one
		OptionalInt firstRepeated = input.chars()
				// The filter condition 'seen.add(i)' returns false if the element 'i' was
				// already in the set
				// The '!' negates this, so we filter for elements that were already in the set
				// (duplicates)
				.filter(i -> !seen.add(i))
				// findFirst() stops the stream processing immediately upon finding the first
				// match
				.findFirst();

		if (firstRepeated.isPresent()) {
			System.out.println("The first repeated character is: " + (char) firstRepeated.getAsInt());
		} else {
			System.out.println("No repeated character found.");
		}
	}

}