package com.test.java8;

import java.util.Arrays;
import java.util.List;

public class ForEachEx {
	public static void main(String[] args) {
		List<String> fruits = Arrays.asList("Orange", "Apple", "Pear");
		fruits.forEach(fruit -> System.out.println(fruit));
		System.out.println("-----------------------");
		// or even more concisely with a method reference:
		fruits.forEach(System.out::println);
		List<String> f = Arrays.asList("Orange", "Apple", "Banana");
		f.forEach(fr -> System.out.println(fr));
	}

}
