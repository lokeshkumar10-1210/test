package com.test.java8;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SpliteratorExample {
	public static void main(String[] args) {
		// Sample data
		String[] names = { "John", "Jane", "Jack", "Doe", "Emily", "Anna" };

		// Create a Spliterator for the array
		Spliterator<String> spliterator = Arrays.spliterator(names);

		// Print characteristics of the Spliterator
		System.out.println("Characteristics: " + spliterator.characteristics());
		System.out.println("Estimated size: " + spliterator.estimateSize());

		// Try to split the Spliterator
		Spliterator<String> spliterator1 = spliterator.trySplit();

		// If spliterator1 is not null, it means the split was successful
		if (spliterator1 != null) {
			System.out.println("Spliterator1 estimated size: " + spliterator1.estimateSize());
			System.out.println("Spliterator2 estimated size: " + spliterator.estimateSize());

			// Process elements using the first spliterator
			System.out.println("Processing elements from spliterator1:");
			spliterator1.forEachRemaining((Consumer<? super String>) System.out::println);
		}

		// Process elements using the second spliterator
		System.out.println("Processing elements from spliterator2:");
		spliterator.forEachRemaining((Consumer<? super String>) System.out::println);
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}