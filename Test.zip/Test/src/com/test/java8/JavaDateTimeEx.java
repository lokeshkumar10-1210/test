package com.test.java8;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Formatter;

public class JavaDateTimeEx {

	public static void main(String[] args) {
		DayOfWeek date = LocalDate.now().plusWeeks(1).getDayOfWeek();
		 
		System.out.println(LocalDate.now().getDayOfMonth());
		System.out.println(date.name());
		System.out.println(LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)));
		System.out.println(LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).plusWeeks(1));
		
		
		//2nd way
		LocalDate now = LocalDate.now();
		
		LocalDate mon1 = now.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
		System.out.println(mon1);

		LocalDate mon2 = now.with(TemporalAdjusters.next(DayOfWeek.MONDAY)).with(TemporalAdjusters.next(DayOfWeek.MONDAY));
		System.out.println(mon2);
		
		ZoneId of = ZoneId.of("Asia/Kolkata");
		DateTimeFormatter.ofPattern("");
		
	}
}