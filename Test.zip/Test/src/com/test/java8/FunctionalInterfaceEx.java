package com.test.java8;

@FunctionalInterface  // Optional annotation
interface MyFunctionalInterface {
    void showMessage(String message); // Single abstract method
    //String message(String str); // error -> not a functional interface
}

// Using Lambda Expression
public class FunctionalInterfaceEx {
    public static void main(String[] args) {
        MyFunctionalInterface obj = message -> System.out.println("Message: " + message);
        obj.showMessage("Hello, Functional Interface!");
    }
}