package com.test.java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SortingEx {

	public static void main(String[] args) {
		List<Double> decimalList = Arrays.asList(12.45, 23.58, 17.13, 42.89, 33.78, 71.85, 56.98, 21.12);

		// decimalList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		decimalList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);

		
		List<String> list = Arrays.asList("Test", "for", "Sorting", "Welcome", "You");
		List<String> sortedNames = list.stream().sorted().collect(Collectors.toList()); // Natural Order number or
																						// string
		sortedNames.forEach(System.out::println);
		
		Stream<String> stream = Stream.of("apple", "banana", "cherry", "date");
		 Stream<String> sortedStream = stream.sorted(Comparator.comparingInt(String::length));
		 sortedStream.forEach(System.out::println);
	}

}
