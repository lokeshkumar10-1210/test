package com.test.java8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorExample {
	public static void main(String[] args) {
		// Create a fixed thread pool with 3 threads
		ExecutorService executor = Executors.newFixedThreadPool(3);

		// Submit tasks (Runnable) to the executor
		for (int i = 0; i < 5; i++) {
			int taskId = i;
			executor.submit(() -> { // Use submit for better tracking, execute also works
				System.out.println("Executing task " + taskId + " on " + Thread.currentThread().getName());
			});
		}

		// Initiate an orderly shutdown of the executor service
		executor.shutdown();

		try {
			// Wait for all tasks to complete execution within a timeout period
			if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
				// Optionally, force shutdown if tasks don't complete in time
				executor.shutdownNow();
			}
		} catch (InterruptedException e) {
			executor.shutdownNow();
			Thread.currentThread().interrupt(); // Preserve interrupt status
		}
	}
}