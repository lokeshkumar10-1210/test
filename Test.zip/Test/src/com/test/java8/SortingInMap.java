package com.test.java8;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class SortingInMap {

	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<>();
		map.put("zz", 113);
		map.put("dd", 41);
		map.put("cc", 89);
		map.put("gg", 63);
		map.put("bb", 110);

		Map<String, Integer> sortedMap = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

		map.entrySet().stream().forEach(e -> System.out.println(e.getKey() + " = " + e.getValue()));
		//map.entrySet().stream().forEach(entry -> System.out.println(entry.getKey() + " = " + entry.getValue()));
		map.keySet().stream().forEach(key -> System.out.println("Key: " + key));
		map.values().stream().forEach(value -> System.out.println("Value: " + value));

	}

}
