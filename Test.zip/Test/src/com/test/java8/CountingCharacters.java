package com.test.java8;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountingCharacters {

	public static void main(String[] args) {
		String s1 = "aabccaaa";
		// output a2b1c2a3

		Map<Character, Long> charCount = s1.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.print(charCount);

		Map<Character, Long> charCount2 = s1.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(c -> c, Collectors.counting()));

		System.out.print(charCount2);

		// Map<Character, Long> charCount3 = s1.chars().mapToObj(c -> (char) c)
		// .collect(Collectors.toMap(Function.identity(), Collectors.counting()));

		// System.out.print(charCount3);

		String input = "aabccaaa";
		Map<Character, Integer> counts = new HashMap<>();
		for (char c : input.toCharArray()) {
			counts.merge(c, 1, Integer::sum);
		}
		System.out.print(counts);

		String str1 = "aabcccccaaa";
		System.out.println(compress(str1));

	}

	public static String compress(String s) {
		if (s == null || s.isEmpty())
			return s;
		StringBuilder compressed = new StringBuilder();
		int count = 0;
		for (int i = 0; i < s.length(); i++) {
			count++;
			// If next character is different, append current char and count
			if (i + 1 >= s.length() || s.charAt(i) != s.charAt(i + 1)) {
				compressed.append(s.charAt(i));
				compressed.append(count);
				count = 0;
			}
		}
		return compressed.toString();
	}
}
