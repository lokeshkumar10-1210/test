package com.test.java8;

public class ReplaceSpacesEx {

	public static void main(String[] args) {

		String input = "Hello   World   Java 8";
		 String noSpaces = input.replaceAll("\\s", "");
		 System.out.println(noSpaces);
	}

}
