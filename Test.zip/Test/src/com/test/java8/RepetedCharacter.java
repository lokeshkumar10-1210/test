package com.test.java8;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RepetedCharacter {
	public static void main(String args[]) {

		System.out.println("\n");
		String str2 = " Chennai  is beautiful place to visit.";

		// Map<Character,Long> map =
		// st2.chars().mapToObj(e->(char)e).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()
		// ));
		// System.out.println(map);

		// Map<Character,Long>
		// res=str2.chars().mapToObj(e->(char)e).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
		// System.out.println(res);

		//Map<Character, Long> res = str2.chars().mapToObj(e -> (char) e)
				//.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting()));
		
		Map<Character, Long> res = str2.chars().mapToObj(e -> (char) e)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(res);

		//System.out.println("repeted_character");
		Character repeted_character = res.entrySet().stream().filter(value ->value.getValue()>1).map(key->key.getKey()).skip(1).findFirst().get();
		System.out.println("repeted_character : " +repeted_character);
		
		Character non_repeted_character = res.entrySet().stream().filter(value ->value.getValue()==1).map(key->key.getKey()).skip(1).findFirst().get();
		System.out.println("repeted_character : " +repeted_character);
		System.out.println("non_repeted_character : " +non_repeted_character);
	}
}
