package com.test.java8;

//Record declaration
record Product(String name, double price) {
}

//Usage
public class RecordEx {
	public static void main(String[] args) {
		// Create an instance
		Product product = new Product("Laptop", 999.99);

		// Access components using accessor methods
		System.out.println("Product Name: " + product.name());
		System.out.println("Product Price: " + product.price());

		// Default toString() implementation
		System.out.println(product.toString()); // Output: Product[name=Laptop, price=999.99]
	}
}