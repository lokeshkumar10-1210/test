package com.test.java8;

import java.util.ArrayList;

import java.util.Arrays;

import java.util.Comparator;

import java.util.DoubleSummaryStatistics;

import java.util.List;

import java.util.Map;

import java.util.Map.Entry;

import java.util.Set;

import java.util.Spliterator;

import java.util.StringJoiner;

import java.util.function.Function;

import java.util.stream.Collector;

import java.util.stream.Collectors;

import java.util.stream.Stream;

public class EmployeeEx {

	public static void main(String[] args) {

		List<Employee> list = EmployeeEx.employeeList();

		// Query 3.1 : How many male and female employees are there in the organization?

		System.out.println();

		/*Map<String, Long> noOfMaleAndFemaleEmployees = list.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));

		System.out.println(noOfMaleAndFemaleEmployees);

		System.out.println();

		// Query 3.2 : Print the name of all departments in the organization?

		List<String> name_of_all_departments = list.stream().map(Employee::getDepartment).distinct()
				.collect(Collectors.toList());

		System.out.println("name of all departments");

		name_of_all_departments.forEach(System.out::println);

		System.out.println();

		list.stream().map(Employee::getDepartment).distinct().forEach(System.out::println);

		System.out.println();

		// Query 3.3 : What is the average age of male and female employees?

		Map<String, Double> average_age_of_male_and_female = list.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingInt(Employee::getAge)));

		System.out.println(average_age_of_male_and_female);

		// csjcsjbcsc

		System.out.println();

		// Query 3.4 : Get the details of highest paid employee in the organization?

		Employee highest_paid_employee = list.stream()
				.collect(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary))).get();

		System.out.println("highest paid employee");

		System.out.println(highest_paid_employee);

		// 2nd ways

		System.out.println();

		Employee highest_paid_employee_2nd = list.stream().max(Comparator.comparingDouble(Employee::getSalary)).get();

		System.out.println(highest_paid_employee_2nd);

		// Query 3.5 : Get the names of all employees who have joined after 2015?

		list.stream().filter(emp -> emp.getYearOfJoining() > 2015).map(Employee::getName).forEach(System.out::println);

		// System.out.println(names_of_all_employees);

		System.out.println();

		list.stream().filter(emp -> emp.getYearOfJoining() > 2015).forEach(System.out::println);

		// Query 3.6 : Count the number of employees in each department?

		Map<String, Long> number_employees_department = list.stream().map(Employee::getDepartment)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println("number_employees_department");

		System.out.println(number_employees_department);

		System.out.println();

		number_employees_department.entrySet().forEach(System.out::println);

		System.out.println();

		Map<String, Long> map1 = list.stream()
				.collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));

		map1.entrySet().forEach(System.out::println);

		System.out.println();

		List<String> str = Arrays.asList("java", "java", "spring", "spring", "hibernate");

		Map<String, Long> map = str.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		map.entrySet().forEach(System.out::println);

		System.out.println();

		// Query 3.7 : What is the average salary of each department?

		Map<String, Double> average_salary_of_each_department = list.stream().collect(
				Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary)));

		System.out.println("average_salary_of_each_department");

		average_salary_of_each_department.entrySet().forEach(System.out::println);

		System.out.println();

		// Query 3.8 : Get the details of youngest male employee in the product
		// development department?

		Employee employee = list.stream()
				.filter(e -> e.getDepartment() == "Product Development" && e.getGender() == "Male")

				.min(Comparator.comparingInt(Employee::getAge)).get();

		System.out.println("employee");

		System.out.println(employee);

		System.out.println();

		Employee employee2 = list.stream()
				.filter(e -> e.getDepartment().equalsIgnoreCase("Product Development")
						&& e.getGender().equalsIgnoreCase("maLE"))

				.min(Comparator.comparingInt(Employee::getAge)).get();

		// collect.forEach(System.out::println);

		System.out.println("employee2");

		System.out.println(employee2);

		// Query 3.9 : Who has the most working experience in the organization?

		Employee most_working_experience_employee = list.stream().min(Comparator.comparing(Employee::getYearOfJoining))
				.get();

		System.out.println("most_working_experience_employee");

		System.out.println(most_working_experience_employee);

		Employee most_working_experience_employee_2ndWays = list.stream()
				.sorted(Comparator.comparingInt(Employee::getYearOfJoining)).findFirst().get();

		System.out.println(most_working_experience_employee_2ndWays);

		System.out.println();

		// Query 3.10 : How many male and female employees are there in the sales and
		// marketing team?

		Map<String, Long> male_and_female_employees_count = list.stream()
				.filter(e -> e.getDepartment().equalsIgnoreCase("Sales And Marketing"))

				.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));

		male_and_female_employees_count.entrySet().forEach(System.out::println);

		System.out.println();

		// Query 3.11 : What is the average salary of male and female employees?

		Map<String, Double> average_salary_of_male_and_female = list.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingDouble(Employee::getSalary)));

		average_salary_of_male_and_female.entrySet().forEach(System.out::println);

		System.out.println();

		// Query 3.12 : List down the names of all employees in each department?

		Map<String, List<Employee>> names_of_all_employees_map2 = list.stream()
				.collect(Collectors.groupingBy(Employee::getDepartment));

		Set<Entry<String, List<Employee>>> entrySet = names_of_all_employees_map2.entrySet();

		for (Entry<String, List<Employee>> entry : entrySet) {

			List<Employee> employees = entry.getValue();

			System.out.println();

			System.out.println("Employees In '" + entry.getKey() + "'");

			for (Employee emp : employees) {

				String name = emp.getName();

				System.out.println(name);

			}

		}

		System.out.println();

		// Query 3.13 : What is the average salary and total salary of the whole
		// organization?

		DoubleSummaryStatistics summaryStatistics = list.stream()
				.collect(Collectors.summarizingDouble(Employee::getSalary));

		double average = summaryStatistics.getAverage();

		double sum = summaryStatistics.getSum();

		double count = summaryStatistics.getCount();

		System.out.println("average :: " + average);

		System.out.println("Sum :: " + sum);

		System.out.println("count :: " + count);

		System.out.println();

		System.out.println("Separate the employees who are younger or equal to 25 years ");

		// Query 3.14 : Separate the employees who are younger or equal to 25 years from
		// those employees who are older than 25 years.

		Map<Boolean, List<Employee>> Separate_the_employees_map2 = list.stream()
				.collect(Collectors.partitioningBy(e -> e.getAge() <= 25));

		List<Employee> younger = Separate_the_employees_map2.get(true);

		System.out.println("============= younger ============= ");

		// younger.forEach(System.out::println);

		for (Employee emp : younger) {

			System.out.println(emp.getName());

		}

		System.out.println();

		System.out.println("============= older than 25 years ============= ");

		List<Employee> older_than_25 = Separate_the_employees_map2.get(false);

		// older_than_25.forEach(System.out::println);

		for (Employee emp : older_than_25) {

			System.out.println(emp.getName());

		}

		System.out.println();

		// Query 3.15 : Who is the oldest employee in the organization? What is his age
		// and which department he belongs to?

		Employee oldest_employee = list.stream().sorted(Comparator.comparing(Employee::getYearOfJoining)).findFirst()
				.get();

		System.out.println("Age :: " + oldest_employee.getAge());

		System.out.println("Department :: " + oldest_employee.getDepartment());

		System.out.println();

		Employee oldest_employee_By_Age = list.stream().max(Comparator.comparing(Employee::getAge)).get();

		System.out.println("oldest_employee_By_Age :: ");

		System.out.println("Name :: " + oldest_employee_By_Age.getName());

		System.out.println("Age :: " + oldest_employee_By_Age.getAge());

		System.out.println("Departments : " + oldest_employee_By_Age.getDepartment());

		String[] languageArray = new String[] { "Java", "C", "C++", "Python", "Scala", "Kotlin" };

		Spliterator<String> spliteratorOfArray = Arrays.spliterator(languageArray);

		spliteratorOfArray.forEachRemaining(System.out::println);

		System.out.println();*/

		List<String> languageList = Arrays.asList("Java", "C", "C++", "Python", "Scala", "Kotlin");

		Spliterator<String> spliteratorOfList = languageList.spliterator();

		spliteratorOfList.forEachRemaining(System.out::println);

		System.out.println("----");

		/*Stream<String> languageStream = Stream.of("Java", "C", "C++", "Python", "Scala", "Kotlin");

		Spliterator<String> spliteratorOfStream = languageStream.spliterator();

		spliteratorOfStream.forEachRemaining(System.out::println);

		System.out.println("==============");

		spliteratorOfStream.tryAdvance(System.out::println);

		System.out.println("--------------------------");

		List<String> languageList_1 = Arrays.asList("Java", "C", "C++", "Python", "Scala", "Kotlin");

		Spliterator<String> languageSpliterator = languageList_1.spliterator();

		languageSpliterator.tryAdvance(System.out::println);

		languageSpliterator.tryAdvance(System.out::println);

		languageSpliterator.tryAdvance(System.out::println);

		languageSpliterator.tryAdvance(System.out::println);

		System.out.println()*/

		/*
		 * StringJoiner stringJoiner = new StringJoiner("|");
		 * 
		 * stringJoiner.add("Facebook");
		 * 
		 * stringJoiner.add("Twitter");
		 * 
		 * stringJoiner.add("YouTube");
		 * 
		 * stringJoiner.add("WhatsApp");
		 * 
		 * stringJoiner.add("LinkedIn");
		 * 
		 * System.out.println(stringJoiner);
		 * 
		 * StringJoiner techElements = new StringJoiner("|");
		 * 
		 * techElements.add("Laptop")
		 * 
		 * .add("Mobile")
		 * 
		 * .add("TV")
		 * 
		 * .add("Totoya")
		 * 
		 * .add("Car");
		 * 
		 * System.out.println(techElements);
		 * 
		 * 
		 * System.out.println("=================");
		 * 
		 * StringJoiner stringJoiner11 = new StringJoiner(", ", "[", "]"); //ctrl+2 then
		 * R
		 * 
		 * stringJoiner11.add("Facebook");
		 * 
		 * stringJoiner11.add("Twitter");
		 * 
		 * stringJoiner11.add("YouTube");
		 * 
		 * stringJoiner11.add("WhatsApp");
		 * 
		 * stringJoiner11.add("LinkedIn");
		 * 
		 * System.out.println(stringJoiner11);
		 * 
		 * System.out.println("--------------------");
		 * 
		 * String joinedString = String.join(" & ", "Facebook", "Twitter", "YouTube",
		 * "WhatsApp", "LinkedIn");
		 * 
		 * System.out.println(joinedString);
		 * 
		 * System.out.println();
		 * 
		 * String[] strArray = new String[] {"Facebook", "Twitter", "YouTube",
		 * "WhatsApp", "LinkedIn","abc"};
		 * 
		 * String joinedString_data = String.join(" | ", strArray);
		 * 
		 * System.out.println(joinedString_data);
		 * 
		 * System.out.println();
		 * 
		 * List<String> listOfStrings = Arrays.asList("Facebook", "Twitter", "YouTube",
		 * "WhatsApp", "LinkedIn");
		 * 
		 * String joinedString_List = String.join(" * ", listOfStrings);
		 * 
		 * System.out.println(joinedString_List);
		 * 
		 * System.out.println("::::::::::::::::");
		 * 
		 * StringJoiner sj = new StringJoiner(":", "[", "]");
		 * 
		 * sj.add("George").add("Sally").add("Fred");
		 * 
		 * String desiredString = sj.toString();
		 * 
		 * System.out.println("desiredString ");
		 * 
		 * System.out.println(desiredString);
		 * 
		 */

		// Java 8 Collectors.joining() :

		List<String> listOfStrings = Arrays.asList("Facebook", "Twitter", "YouTube", "WhatsApp", "LinkedIn");

		String joinedString = listOfStrings.stream().collect(Collectors.joining());

		System.out.println(joinedString);

		System.out.println();

		String joinedString_with_delimiter = listOfStrings.stream().collect(Collectors.joining(" $ "));

		System.out.println(joinedString_with_delimiter);

		System.out.println();

		String joinedString_with_delimiter_pre_suffix = listOfStrings.stream()
				.collect(Collectors.joining(" $ ", "{", "}"));

		System.out.println(joinedString_with_delimiter_pre_suffix);

	}

	public static List<Employee> employeeList() {

		List<Employee> employeeList = new ArrayList<Employee>();

		employeeList.add(new Employee(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));

		employeeList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));

		employeeList.add(new Employee(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));

		employeeList.add(new Employee(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));

		employeeList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));

		employeeList.add(new Employee(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));

		employeeList.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));

		employeeList.add(new Employee(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));

		employeeList.add(new Employee(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));

		employeeList.add(new Employee(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));

		employeeList.add(new Employee(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));

		employeeList.add(new Employee(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));

		employeeList.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));

		employeeList.add(new Employee(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));

		employeeList.add(new Employee(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));

		employeeList.add(new Employee(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));

		employeeList.add(new Employee(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));

		return employeeList;

	}

}

//list. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Streamlist. Stream 