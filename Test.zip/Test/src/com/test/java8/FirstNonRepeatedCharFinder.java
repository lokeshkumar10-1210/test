package com.test.java8;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.OptionalInt;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FirstNonRepeatedCharFinder {

	public static void main(String[] args) {

		String input = "swiss";
		//String input = "aabb";

		Character firstNonRepeated = input.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(entry -> entry.getValue() == 1).map(Map.Entry::getKey).findFirst()
				.orElse(null);

		System.out.println(firstNonRepeated); // w

	}

}