package com.test.java8;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ListToMapExample {

	public static void main(String[] args) {

		List<String> items = List.of("apple", "banana", "cherry");

		Map<String, Integer> output = items.stream().collect(Collectors.toMap(item -> item, item -> item.length()));
		Map<String, Integer> output1 = items.stream().collect(Collectors.toMap(item -> item, String::length));

		output.forEach((key, value) -> System.out.println(key + " : " + value));
		output1.forEach((k, v) -> System.out.println(k + " - " + v));

	}

}
