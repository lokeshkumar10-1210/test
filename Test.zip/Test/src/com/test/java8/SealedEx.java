package com.test.java8;

sealed interface Shape permits Circle, Rectangle, Triangle {
    double area();
}

// Only these classes can implement Shape
non-sealed class Circle implements Shape {
    private double radius;
    Circle(double radius) { this.radius = radius; }
    public double area() { return Math.PI * radius * radius; }
}

final class Rectangle implements Shape {
    private double length, width;
    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    public double area() { return length * width; }
}

final class Triangle implements Shape {
    private double base, height;
    Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }
    public double area() { return 0.5 * base * height; }
}

class Circle2 extends Circle {

	Circle2(double radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}
	
   
    public double area() { return Math.PI * 1 * 6; }
	
}

public class SealedEx {
    public static void main(String[] args) {
        Shape s = new Circle2(5);
        System.out.println("Area: " + s.area());  // Prints area of Circle
    }
}

/* Only Circle, Rectangle, and Triangle can implement Shape. 
Any other class trying to implement Shape will cause a compilation error. */