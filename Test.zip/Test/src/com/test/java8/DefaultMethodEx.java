package com.test.java8;

interface Vehicle {
    // Default method with implementation
    default void start() {
        System.out.println("Vehicle is starting...");
    }
    default void start1() {
        System.out.println("Vehicle is starting...");
    }
    
}

// Implementing class
class Car implements Vehicle {
    // No need to override the start() method unless customization is required
}

// Another implementing class overriding the default method
class Bike implements Vehicle {
    @Override
    public void start() {
        System.out.println("Bike is starting...");
    }
}

public class DefaultMethodEx {
    public static void main(String[] args) {
        Car car = new Car();
        car.start(); // Uses default implementation

        Bike bike = new Bike();
        bike.start(); // Uses overridden implementation
    }
}